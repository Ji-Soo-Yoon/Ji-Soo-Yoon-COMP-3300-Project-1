﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System;

namespace JisooYoonProject1.Model
{
    public class Car
    {
        public string Make { get; private set; }
        public string Model { get; private set; }
        public double Mpg { get; private set; }
        public double Price { get; private set; }

        public Car(string make, string model, double mpg, double price)
        {
            this.Make = !string.IsNullOrWhiteSpace(make) ? make : "Unknown";
            this.Model = !string.IsNullOrWhiteSpace(model) ? model : "Unknown";
            this.Mpg = mpg > 0 ? mpg : 1;
            this.Price = price >= 0 ? price : 0;
        }

        public string GetCarInfo()
        {
            return $"{Make} {Model} - {Mpg:F2} MPG - {Price:C2}";
        }
    }
}
