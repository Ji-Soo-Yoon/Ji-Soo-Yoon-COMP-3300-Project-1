﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace JisooYoonProject1.Model
{
    public class Shopper
    {
        public string Name { get; private set; }
        public double MoneyAvailable { get; private set; }

        private List<Car> Cars;

        public Shopper(string name, double moneyAvailable)
        {
            if (string.IsNullOrWhiteSpace(name))
                throw new ArgumentException("Name cannot be null or empty.", nameof(name));
            if (moneyAvailable < 0)
                throw new ArgumentException("MoneyAvailable cannot be negative.", nameof(moneyAvailable));

            this.Name = name;
            this.MoneyAvailable = moneyAvailable;
            this.Cars = new List<Car>();
        }

        public bool CanPurchase(Car car)
        {
            if (car == null)
                throw new ArgumentNullException(nameof(car));
            double totalCost = car.Price + (car.Price * CarLot.TaxRate);
            return this.MoneyAvailable >= totalCost;
        }

        public bool PurchaseCar(Car car)
        {
            if (car == null)
                throw new ArgumentNullException(nameof(car));
            double totalCost = car.Price + (car.Price * CarLot.TaxRate);
            if (this.MoneyAvailable >= totalCost)
            {
                this.Cars.Add(car);
                this.MoneyAvailable -= totalCost;
                return true;
            }
            return false;
        }

        public bool SpendMoney(double amount)
        {
            if (amount <= 0)
                throw new ArgumentException("Amount must be greater than 0.", nameof(amount));
            if (amount > this.MoneyAvailable)
                return false;
            this.MoneyAvailable -= amount;
            return true;
        }

        public void AddMoney(double amount)
        {
            if (amount <= 0)
                throw new ArgumentException("Amount must be greater than 0.", nameof(amount));
            this.MoneyAvailable += amount;
        }

        public void AddCar(Car car)
        {
            if (car == null)
                throw new ArgumentNullException(nameof(car));
            this.Cars.Add(car);
        }

        public List<Car> GetPurchasedCars()
        {
            return new List<Car>(this.Cars);
        }

        public string GetShopperInfo()
        {
            return $"{Name} has {MoneyAvailable:C2} available and owns {Cars.Count} car(s).";
        }
    }
}

