﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JisooYoonProject1.Model
{
    public class CarLot
    {
        // Private data member
        private List<Car> inventory;

        // Public constant for tax rate
        public const double TaxRate = 0.078; // 7.8%

        // Expression-bodied property for total number of cars
        public int Count => this.inventory?.Count ?? 0;

        // Expression-bodied property to return inventory list
        public List<Car> Inventory => this.inventory;

        // Default constructor
        public CarLot()
        {
            this.inventory = new List<Car>();
            this.StockLotWithDefaultInventory();
        }

        // Private helper method to add default cars
        private void StockLotWithDefaultInventory()
        {
            this.inventory.Add(new Car("Ford", "Focus ST", 28.3, 26298.98));
            this.inventory.Add(new Car("Chevrolet", "Camaro ZL1", 19.0, 65401.23));
            this.inventory.Add(new Car("Honda", "Accord Sedan EX", 30.2, 26780.00));
            this.inventory.Add(new Car("Lexus", "ES 350", 24.1, 42101.10));
        }

        // Add a new car to inventory with preconditions
        public void AddCar(string make, string model, double mpg, double price)
        {
            if (string.IsNullOrWhiteSpace(make) || string.IsNullOrWhiteSpace(model) || mpg <= 0 || price < 0)
                return; // Invalid input, do nothing

            this.inventory.Add(new Car(make, model, mpg, price));
        }

        // Find cars by make (case-insensitive)
        public List<Car> FindCarsByMake(string make)
        {
            if (string.IsNullOrWhiteSpace(make)) return null;

            var matchingCars = this.inventory
                .Where(c => !string.IsNullOrWhiteSpace(c.Make) &&
                            c.Make.Equals(make, StringComparison.OrdinalIgnoreCase))
                .ToList();

            return matchingCars.Count > 0 ? matchingCars : null;
        }

        // Find a car by make and model (case-insensitive)
        public Car FindCarByMakeModel(string make, string model)
        {
            if (string.IsNullOrWhiteSpace(make) || string.IsNullOrWhiteSpace(model)) return null;

            return this.inventory
                .FirstOrDefault(c => !string.IsNullOrWhiteSpace(c.Make) &&
                                     !string.IsNullOrWhiteSpace(c.Model) &&
                                     c.Make.Equals(make, StringComparison.OrdinalIgnoreCase) &&
                                     c.Model.Equals(model, StringComparison.OrdinalIgnoreCase));
        }

        // Purchase a car and remove it from inventory
        public Car PurchaseCar(string make, string model)
        {
            if (string.IsNullOrWhiteSpace(make) || string.IsNullOrWhiteSpace(model)) return null;

            Car carToPurchase = this.FindCarByMakeModel(make, model);

            if (carToPurchase != null)
                this.inventory.Remove(carToPurchase);

            return carToPurchase; // Returns null if not found
        }

        // Calculate total cost of purchase including tax
        public double GetTotalCostOfPurchase(Car car)
        {
            if (car == null) return 0.0;
            return car.Price + (car.Price * TaxRate);
        }

        // Find the least expensive car
        public Car FindLeastExpensiveCar() =>
            (this.inventory != null && this.inventory.Count > 0)
                ? this.inventory.OrderBy(c => c.Price).First()
                : null;

        // Find the most expensive car
        public Car FindMostExpensiveCar() =>
            (this.inventory != null && this.inventory.Count > 0)
                ? this.inventory.OrderByDescending(c => c.Price).First()
                : null;

        // Find the car with the best MPG
        public Car FindBestMPGCar() =>
            (this.inventory != null && this.inventory.Count > 0)
                ? this.inventory.OrderByDescending(c => c.Mpg).First()
                : null;

        // Find the car with the worst MPG
        public Car FindWorstMPGCar() =>
            (this.inventory != null && this.inventory.Count > 0)
                ? this.inventory.OrderBy(c => c.Mpg).First()
                : null;
    }
}

