﻿using System;
using System.Text;
using System.Windows.Forms;
using JisooYoonProject1.Model;

namespace JisooYoonProject1
{
    public partial class InventoryDetailsForm : Form
    {
        public InventoryDetailsForm(CarLot carLot)
        {
            InitializeComponent();
            DisplayInventoryDetails(carLot);
        }

        private void DisplayInventoryDetails(CarLot carLot)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"Inventory of {carLot.Count} cars.");

            foreach (Car car in carLot.Inventory)
            {
                sb.AppendLine($"{car.Make} {car.Model} {car.Price:C2} {car.Mpg:F1}mpg");
            }

            sb.AppendLine();

            // Most expensive
            Car mostExpensive = carLot.FindMostExpensiveCar();
            if (mostExpensive != null)
            {
                sb.AppendLine("Most expensive:");
                sb.AppendLine($"{mostExpensive.Make} {mostExpensive.Model} {mostExpensive.Price:C2} {mostExpensive.Mpg:F1}mpg");
            }

            // Least expensive
            Car leastExpensive = carLot.FindLeastExpensiveCar();
            if (leastExpensive != null)
            {
                sb.AppendLine("Least expensive:");
                sb.AppendLine($"{leastExpensive.Make} {leastExpensive.Model} {leastExpensive.Price:C2} {leastExpensive.Mpg:F1}mpg");
            }

            // Best MPG
            Car bestMPG = carLot.FindBestMPGCar();
            if (bestMPG != null)
            {
                sb.AppendLine("Best MPG:");
                sb.AppendLine($"{bestMPG.Make} {bestMPG.Model} {bestMPG.Price:C2} {bestMPG.Mpg:F1}mpg");
            }

            // Worst MPG
            Car worstMPG = carLot.FindWorstMPGCar();
            if (worstMPG != null)
            {
                sb.AppendLine("Worst MPG:");
                sb.AppendLine($"{worstMPG.Make} {worstMPG.Model} {worstMPG.Price:C2} {worstMPG.Mpg:F1}mpg");
            }

            txtDetails.Text = sb.ToString();
        }
    }
}
