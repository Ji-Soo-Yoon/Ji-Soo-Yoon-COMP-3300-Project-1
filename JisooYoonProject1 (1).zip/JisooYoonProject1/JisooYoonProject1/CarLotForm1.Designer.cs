﻿namespace JisooYoonProject1
{
    partial class CarLotForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.lstInventory = new System.Windows.Forms.ListBox();
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.inventoryMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addCarMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewDetailsMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnCreateShopper = new System.Windows.Forms.Button();
            this.lblShopperInfo = new System.Windows.Forms.Label();
            this.btnPurchaseCar = new System.Windows.Forms.Button();
            this.btnViewDetails = new System.Windows.Forms.Button();
            this.menuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // lstInventory
            // 
            this.lstInventory.FormattingEnabled = true;
            this.lstInventory.ItemHeight = 24;
            this.lstInventory.Location = new System.Drawing.Point(45, 75);
            this.lstInventory.Name = "lstInventory";
            this.lstInventory.Size = new System.Drawing.Size(780, 270);
            this.lstInventory.TabIndex = 0;
            // 
            // menuStrip
            // 
            this.menuStrip.ImageScalingSize = new System.Drawing.Size(30, 30);
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.inventoryMenuItem});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Size = new System.Drawing.Size(900, 42);
            this.menuStrip.TabIndex = 1;
            this.menuStrip.Text = "menuStrip";
            // 
            // inventoryMenuItem
            // 
            this.inventoryMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addCarMenuItem,
            this.viewDetailsMenuItem});
            this.inventoryMenuItem.Name = "inventoryMenuItem";
            this.inventoryMenuItem.Size = new System.Drawing.Size(126, 38);
            this.inventoryMenuItem.Text = "Inventory";
            // 
            // addCarMenuItem
            // 
            this.addCarMenuItem.Name = "addCarMenuItem";
            this.addCarMenuItem.Size = new System.Drawing.Size(272, 42);
            this.addCarMenuItem.Text = "Add New Car";
            this.addCarMenuItem.Click += new System.EventHandler(this.addCarMenuItem_Click);
            // 
            // viewDetailsMenuItem
            // 
            this.viewDetailsMenuItem.Name = "viewDetailsMenuItem";
            this.viewDetailsMenuItem.Size = new System.Drawing.Size(272, 42);
            this.viewDetailsMenuItem.Text = "View Details";
            this.viewDetailsMenuItem.Click += new System.EventHandler(this.viewDetailsMenuItem_Click);
            // 
            // btnCreateShopper
            // 
            this.btnCreateShopper.Location = new System.Drawing.Point(45, 360);
            this.btnCreateShopper.Name = "btnCreateShopper";
            this.btnCreateShopper.Size = new System.Drawing.Size(225, 45);
            this.btnCreateShopper.TabIndex = 2;
            this.btnCreateShopper.Text = "Create Shopper";
            this.btnCreateShopper.UseVisualStyleBackColor = true;
            this.btnCreateShopper.Click += new System.EventHandler(this.btnCreateShopper_Click);
            // 
            // lblShopperInfo
            // 
            this.lblShopperInfo.AutoSize = true;
            this.lblShopperInfo.Location = new System.Drawing.Point(300, 372);
            this.lblShopperInfo.Name = "lblShopperInfo";
            this.lblShopperInfo.Size = new System.Drawing.Size(0, 24);
            this.lblShopperInfo.TabIndex = 3;
            // 
            // btnPurchaseCar
            // 
            this.btnPurchaseCar.Location = new System.Drawing.Point(45, 420);
            this.btnPurchaseCar.Name = "btnPurchaseCar";
            this.btnPurchaseCar.Size = new System.Drawing.Size(225, 45);
            this.btnPurchaseCar.TabIndex = 4;
            this.btnPurchaseCar.Text = "Purchase Car";
            this.btnPurchaseCar.UseVisualStyleBackColor = true;
            this.btnPurchaseCar.Click += new System.EventHandler(this.btnPurchaseCar_Click);
            // 
            // btnViewDetails
            // 
            this.btnViewDetails.Location = new System.Drawing.Point(300, 420);
            this.btnViewDetails.Name = "btnViewDetails";
            this.btnViewDetails.Size = new System.Drawing.Size(225, 45);
            this.btnViewDetails.TabIndex = 5;
            this.btnViewDetails.Text = "View Inventory Details";
            this.btnViewDetails.UseVisualStyleBackColor = true;
            this.btnViewDetails.Click += new System.EventHandler(this.btnViewDetails_Click);
            // 
            // CarLotForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(900, 495);
            this.Controls.Add(this.btnViewDetails);
            this.Controls.Add(this.btnPurchaseCar);
            this.Controls.Add(this.lblShopperInfo);
            this.Controls.Add(this.btnCreateShopper);
            this.Controls.Add(this.lstInventory);
            this.Controls.Add(this.menuStrip);
            this.MainMenuStrip = this.menuStrip;
            this.Name = "CarLotForm";
            this.Text = "Car Lot Inventory";
            this.Load += new System.EventHandler(this.CarLotForm_Load);
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.ListBox lstInventory;
        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolStripMenuItem inventoryMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addCarMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewDetailsMenuItem;
        private System.Windows.Forms.Button btnCreateShopper;
        private System.Windows.Forms.Label lblShopperInfo;
        private System.Windows.Forms.Button btnPurchaseCar;
        private System.Windows.Forms.Button btnViewDetails;
    }
}
