﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System;
using System.Windows.Forms;

namespace JisooYoonProject1
{
    public partial class AddCarForm : Form
    {
        public AddCarForm()
        {
            InitializeComponent();
        }

        public string CarMake => txtMake.Text.Trim();
        public string CarModel => txtModel.Text.Trim();
        public double CarMPG => double.TryParse(txtMPG.Text, out double mpg) ? mpg : 0;
        public double CarPrice => double.TryParse(txtPrice.Text, out double price) ? price : 0;

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            // Basic validation
            if (string.IsNullOrWhiteSpace(CarMake) ||
                string.IsNullOrWhiteSpace(CarModel) ||
                CarMPG <= 0 || CarPrice < 0)
            {
                MessageBox.Show("Please enter valid car details.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}

