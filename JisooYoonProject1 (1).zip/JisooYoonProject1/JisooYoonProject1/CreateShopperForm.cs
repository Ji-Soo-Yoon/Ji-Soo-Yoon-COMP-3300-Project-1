﻿using System;
using System.Windows.Forms;
using System.Xml.Linq;

namespace JisooYoonProject1
{
    public partial class CreateShopperForm : Form
    {
        public CreateShopperForm()
        {
            InitializeComponent();
        }

        public string ShopperName => txtName.Text.Trim();
        public double ShopperMoney => double.TryParse(txtMoney.Text, out double money) ? money : 0;

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(ShopperName) || ShopperMoney < 0)
            {
                MessageBox.Show("Please enter a valid name and non-negative amount.", "Validation Error");
                return;
            }

            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}
