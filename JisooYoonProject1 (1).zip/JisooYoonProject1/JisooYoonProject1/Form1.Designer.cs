﻿namespace JisooYoonProject1
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        public System.Windows.Forms.Button btnOpenCarLot;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.btnOpenCarLot = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnOpenCarLot
            // 
            this.btnOpenCarLot.Location = new System.Drawing.Point(45, 45);
            this.btnOpenCarLot.Name = "btnOpenCarLot";
            this.btnOpenCarLot.Size = new System.Drawing.Size(225, 45);
            this.btnOpenCarLot.TabIndex = 0;
            this.btnOpenCarLot.Text = "Open Car Lot";
            this.btnOpenCarLot.UseVisualStyleBackColor = true;
            this.btnOpenCarLot.Click += new System.EventHandler(this.btnOpenCarLot_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(330, 150);
            this.Controls.Add(this.btnOpenCarLot);
            this.Name = "Form1";
            this.Text = "Launcher";
            this.ResumeLayout(false);
        }

        #endregion
    }
}
