﻿using System;
using System.Windows.Forms;
using JisooYoonProject1.Model;

namespace JisooYoonProject1
{
    public partial class CarLotForm : Form
    {
        private CarLot carLot;
        private Shopper currentShopper;

        public CarLotForm()
        {
            InitializeComponent();
            carLot = new CarLot(); // Loads default inventory
        }

        private void CarLotForm_Load(object sender, EventArgs e)
        {
            lstInventory.Items.Clear();

            foreach (Car car in carLot.Inventory)
            {
                lstInventory.Items.Add($"{car.Make} {car.Model} {car.Price:C2} {car.Mpg:F1}mpg");
            }
        }

        private void addCarMenuItem_Click(object sender, EventArgs e)
        {
            AddCarForm addForm = new AddCarForm();

            if (addForm.ShowDialog() == DialogResult.OK)
            {
                string make = addForm.CarMake;
                string model = addForm.CarModel;
                double mpg = addForm.CarMPG;
                double price = addForm.CarPrice;

                carLot.AddCar(make, model, mpg, price);
                lstInventory.Items.Add($"{make} {model} {price:C2} {mpg:F1}mpg");
            }
        }

        private void btnCreateShopper_Click(object sender, EventArgs e)
        {
            CreateShopperForm shopperForm = new CreateShopperForm();

            if (shopperForm.ShowDialog() == DialogResult.OK)
            {
                string name = shopperForm.ShopperName;
                double money = shopperForm.ShopperMoney;

                currentShopper = new Shopper(name, money);
                lblShopperInfo.Text = $"{name} has {money:C2} available.";
            }
        }

        private void btnPurchaseCar_Click(object sender, EventArgs e)
        {
            if (currentShopper == null)
            {
                MessageBox.Show("Please create a shopper first.", "No Shopper", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (lstInventory.SelectedItem == null)
            {
                MessageBox.Show("Please select a car from the inventory.", "No Car Selected", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string selectedText = lstInventory.SelectedItem.ToString();
            string[] parts = selectedText.Split(' ');
            if (parts.Length < 4)
            {
                MessageBox.Show("Invalid car selection format.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string make = parts[0];
            string model = parts[1];

            Car selectedCar = carLot.FindCarByMakeModel(make, model);
            if (selectedCar == null)
            {
                MessageBox.Show("Car not found in inventory.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!currentShopper.CanPurchase(selectedCar))
            {
                MessageBox.Show("You do not have enough money to purchase this car.", "Insufficient Funds", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            currentShopper.PurchaseCar(selectedCar);
            carLot.PurchaseCar(make, model);
            lstInventory.Items.Remove(lstInventory.SelectedItem);

            MessageBox.Show($"🎉 Congratulations!\nYou purchased: {selectedCar.Make} {selectedCar.Model}\nPrice: {selectedCar.Price:C2}\nRemaining Balance: {currentShopper.MoneyAvailable:C2}", "Purchase Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);

            lblShopperInfo.Text = $"{currentShopper.Name} has {currentShopper.MoneyAvailable:C2} available.";
        }

        private void viewDetailsMenuItem_Click(object sender, EventArgs e)
        {
            InventoryDetailsForm detailsForm = new InventoryDetailsForm(carLot);
            detailsForm.ShowDialog();
        }

        private void btnViewDetails_Click(object sender, EventArgs e)
        {
            InventoryDetailsForm detailsForm = new InventoryDetailsForm(carLot);
            detailsForm.ShowDialog();
        }

    }
}
