﻿namespace JisooYoonProject1
{
    partial class InventoryDetailsForm
    {
        public System.Windows.Forms.TextBox txtDetails;
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.txtDetails = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // txtDetails
            // 
            this.txtDetails.Location = new System.Drawing.Point(30, 30);
            this.txtDetails.Multiline = true;
            this.txtDetails.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtDetails.ReadOnly = true;
            this.txtDetails.Size = new System.Drawing.Size(750, 600);
            this.txtDetails.TabIndex = 0;
            // 
            // InventoryDetailsForm
            // 
            this.ClientSize = new System.Drawing.Size(810, 675);
            this.Controls.Add(this.txtDetails);
            this.Name = "InventoryDetailsForm";
            this.Text = "Inventory Details";
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
